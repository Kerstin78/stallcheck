---
layout: default
title: Über StallCheck
---

# Über StallCheck

StallCheck ist entstanden aus über 40 Jahren Erfahrung in der Pferdehaltung. Unser Ziel: Einen transparenten, digitalen Qualitätscheck für Pferdebetriebe zu schaffen – unabhängig, verständlich und fair.
