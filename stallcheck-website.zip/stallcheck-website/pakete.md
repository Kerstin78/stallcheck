---
layout: default
title: Pakete & Preise
---

# Pakete & Preise

- **Basis-Check (10 Fragen):** 19 €
- **Zusatzpaket Haltungsform:** 15 €
- **Zusatzpaket Hygiene & Pflege:** 15 €
- **Zusatzpaket Sicherheit:** 15 €
- **Komplettpaket (inkl. aller Checks & Bewertung):** 100 €

Die kostenpflichtigen Pakete sind aktuell in Vorbereitung. Bei Interesse kontaktieren Sie uns gerne.
