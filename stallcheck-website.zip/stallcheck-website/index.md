---
layout: default
title: Startseite
---

# Willkommen bei StallCheck

Digitale Stallbewertung leicht gemacht – fair, sicher und nachvollziehbar.

Mit dem StallCheck erhalten Sie eine einfache Möglichkeit, Ihren Pferdebetrieb selbst zu bewerten – kostenlos oder als erweiterte Prüfung mit Auswertung.

[Zum kostenlosen Selbstcheck](selbstcheck)
